# EDA on Retail Sales Data

**Track:** Data Analytics
**Level:** 1
**Task:** 1 — EDA on Retail Sales Data
**Intern:** Saiman (Ganeshan M)

## Objective
Perform a thorough Exploratory Data Analysis on a retail sales dataset to uncover patterns, customer behaviour trends, and actionable business insights.

## Tech Stack
Python, pandas, matplotlib, seaborn, Jupyter Notebook

## Dataset
`retail_sales_data.csv` — 8,000 synthetic retail transactions spanning Jan 2023–Dec 2024, with realistic seasonality (holiday-season revenue spike), 7 product categories, 5 regions, and customer demographics.

> **Why synthetic data:** The task's Self-Sourcing Guideline points to Kaggle datasets ("superstore sales", "retail sales data"), which require a Kaggle account/login that isn't accessible from the environment used to prepare this submission. A structurally realistic synthetic dataset was generated instead (see `gen_retail_data.py` logic referenced in the notebook), so every technique in the notebook — time series analysis, demographic breakdowns, correlation heatmaps — transfers directly if you later swap in a real Kaggle CSV with matching column names.

## What's in this folder
- `EDA_Retail_Sales.ipynb` — full analysis notebook (executed, with all charts embedded as outputs)
- `retail_sales_data.csv` — the dataset
- `output_*.png` — exported chart images (time series, demographics, product analysis, correlation heatmap, region/day-of-week breakdown)

## Feature Checklist Coverage
- [x] Load dataset, initial inspection (shape, dtypes, nulls)
- [x] Descriptive statistics (mean, median, mode, std dev)
- [x] Monthly and quarterly sales trend line/bar charts
- [x] Customer demographics: age distribution, gender breakdown
- [x] Top 10 best-selling products; revenue by category
- [x] Correlation heatmap
- [x] Additional visualisation: revenue by region and day-of-week
- [x] Markdown observations after every chart
- [x] Conclusion with 3 specific, actionable business recommendations

## How to Run
```bash
pip install pandas numpy matplotlib seaborn jupyter
jupyter notebook EDA_Retail_Sales.ipynb
```
