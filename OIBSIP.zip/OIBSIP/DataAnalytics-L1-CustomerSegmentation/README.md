# Customer Segmentation Analysis

**Track:** Data Analytics
**Level:** 1
**Task:** 2 — Customer Segmentation Analysis
**Intern:** Saiman (Ganeshan M)

## Objective
Apply clustering algorithms to segment an e-commerce company's customer base into distinct groups based on purchasing behaviour, enabling targeted marketing strategies.

## Tech Stack
Python, pandas, scikit-learn (KMeans), matplotlib, seaborn, Jupyter Notebook

## Dataset
`retail_sales_data.csv` (same transaction log used in the EDA task) aggregated to the customer level to compute RFM (Recency, Frequency, Monetary) features. This mirrors the structure of the UCI "Online Retail" dataset referenced in the task's Self-Sourcing Guideline.

## What's in this folder
- `Customer_Segmentation_Analysis.ipynb` — full analysis notebook (executed, with all charts embedded)
- `retail_sales_data.csv` — source transaction data
- `output_elbow.png`, `output_clusters.png`, `output_cluster_counts.png` — exported chart images

## Feature Checklist Coverage
- [x] Load dataset, handle missing/inconsistent data
- [x] Descriptive statistics: avg purchase value, purchase frequency, CLV proxy
- [x] Feature selection: RFM (Recency, Frequency, Monetary)
- [x] StandardScaler normalisation before clustering
- [x] K-Means clustering with Elbow Method to determine optimal K (K=4)
- [x] Cluster visualisation via scatter plots (2 feature-pair combinations)
- [x] Cluster profiling with mean feature values and customer-type description
- [x] Bar chart: customers per cluster
- [x] Insights: recommended marketing action per segment

## How to Run
```bash
pip install pandas numpy matplotlib seaborn scikit-learn jupyter
jupyter notebook Customer_Segmentation_Analysis.ipynb
```
