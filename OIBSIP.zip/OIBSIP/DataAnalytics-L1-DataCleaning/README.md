# Cleaning Data

**Track:** Data Analytics
**Level:** 1
**Task:** 3 — Cleaning Data
**Intern:** Saiman (Ganeshan M)

## Objective
Demonstrate professional-level data cleaning skills by taking a deliberately messy dataset and systematically transforming it into a clean, analysis-ready dataset, with every decision documented.

## Tech Stack
Python, pandas, numpy, Jupyter Notebook

## Dataset
`messy_customer_data.csv` — a purpose-built messy customer-orders dataset (1,260 rows) containing every problem category the task requires: missing values, exact duplicate rows, inconsistent categorical formatting (`Male`/`male`/`M`), mixed date formats, a currency-symbol-contaminated numeric column, and genuine outliers (negative/implausible ages, extreme purchase amounts).

> **Why a purpose-built dataset:** The task's Self-Sourcing Guideline suggests searching Kaggle for a "dirty dataset for data cleaning practice" (e.g. Titanic, Housing). Kaggle isn't reachable from the environment used to prepare this submission, so a dataset was generated with the exact same category of real-world data-quality problems baked in on purpose — the cleaning methodology demonstrated is identical to what you'd apply to Titanic or Housing.

## What's in this folder
- `Data_Cleaning.ipynb` — full cleaning notebook (executed, with data quality report and before/after comparison)
- `messy_customer_data.csv` — the raw, messy dataset
- `cleaned_customer_data.csv` — the final cleaned output

## Feature Checklist Coverage
- [x] Data quality report: nulls per column, duplicates, dtype issues, value range anomalies
- [x] Missing data handling: per-column strategy (median/mode/explicit label), each justified individually
- [x] Duplicate removal, with count documented
- [x] Standardisation: `Gender`, `City`, and mixed-format `SignupDate` all normalised
- [x] Outlier detection via IQR method on `Age` and `PurchaseAmount`, with a documented cap-vs-remove decision for each
- [x] Data type correction (int/float/datetime as appropriate)
- [x] Before vs. after summary table
- [x] Cleaned dataset saved to a new CSV

## How to Run
```bash
pip install pandas numpy jupyter
jupyter notebook Data_Cleaning.ipynb
```
